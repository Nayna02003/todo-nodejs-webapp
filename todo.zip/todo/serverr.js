const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root23',
  database: 'todo' // Adjust this to your database name
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the database');
});

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Handle signup POST request
app.post('/signup', (req, res) => {
  const { username, email, password } = req.body;

  // Validate form data (you can add more validation as needed)
  if (!username || !email || !password) {
    return res.status(400).send('Username, email, and password are required');
  }

  // Insert data into the database
  const sql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
  connection.query(sql, [username, email, password], (err, result) => {
    if (err) {
      console.error('Error inserting user:', err);
      return res.status(500).send('Error signing up');
    }
    console.log('User registered successfully');
    res.redirect('/todoo.html'); // Redirect to todoo.html after successful signup
  });
});

// Handle login POST request
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Query database to check user credentials
  const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
  connection.query(sql, [email, password], (err, results) => {
    if (err) {
      console.error('Error executing query:', err);
      return res.status(500).send('Internal server error');
    }

    if (results.length > 0) {
      res.redirect('/todoo.html'); // Redirect to todoo.html after successful login
    } else {
      res.status(401).send('Login failed');
    }
  });
});

// Start server
const PORT = process.env.PORT || 3008;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
